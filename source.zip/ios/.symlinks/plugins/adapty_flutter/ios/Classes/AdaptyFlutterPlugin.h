#import <Flutter/Flutter.h>

@interface AdaptyFlutterPlugin : NSObject<FlutterPlugin>
@end
