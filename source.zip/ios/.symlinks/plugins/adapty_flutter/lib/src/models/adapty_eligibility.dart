//
//  adapty_eligibility.dart
//  Adapty
//
//  Created by Aleksei Valiano on 25.11.2022.
//

part 'private/adapty_eligibility_json_builder.dart';

enum AdaptyEligibility {
  unknown,
  ineligible,
  eligible,
}
