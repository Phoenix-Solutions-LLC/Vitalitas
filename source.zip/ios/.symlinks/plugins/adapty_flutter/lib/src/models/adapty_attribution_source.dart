//
//  adapty_attribution_source.dart
//  Adapty
//
//  Created by Aleksei Valiano on 25.11.2022.
//

part 'private/adapty_attribution_source_json_builder.dart';

enum AdaptyAttributionSource {
  adjust,
  appsflyer,
  branch,
  appleSearchAds,
  custom,
}
