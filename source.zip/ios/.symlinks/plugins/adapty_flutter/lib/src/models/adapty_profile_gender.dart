//
//  adapty_profile_gender.dart
//  Adapty
//
//  Created by Aleksei Valiano on 25.11.2022.
//

part 'private/adapty_profile_gender_json_builder.dart';

enum AdaptyProfileGender {
  female,
  male,
  other,
}
