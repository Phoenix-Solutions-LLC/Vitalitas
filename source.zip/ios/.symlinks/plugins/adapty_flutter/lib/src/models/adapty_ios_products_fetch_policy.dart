//
//  adapty_ios_products_fetch_policy.dart
//  Adapty
//
//  Created by Aleksei Goncharov on 1.12.2022.
//

part 'private/adapty_ios_products_fetch_policy_json_builder.dart';

enum AdaptyIOSProductsFetchPolicy {
  defaultPolicy,
  waitForReceiptValidation,
}
