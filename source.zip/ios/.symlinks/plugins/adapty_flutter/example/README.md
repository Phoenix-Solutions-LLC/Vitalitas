This project is a starting point for a Flutter application with a Adapty integration. For help 
getting started with, view our [online documentation](https://docs.adapty.io).