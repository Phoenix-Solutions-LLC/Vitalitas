// Copyright 2013 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#import <Foundation/Foundation.h>
#import <google_sign_in_ios/FLTGoogleSignInPlugin.h>

FOUNDATION_EXPORT double google_sign_inVersionNumber;
FOUNDATION_EXPORT const unsigned char google_sign_inVersionString[];
