## 5.5.1

* Fixes passing `serverClientId` via the channelled `init` call
* Updates minimum Flutter version to 2.10.

## 5.5.0

* Adds override for `GoogleSignInPlatform.initWithParams`.

## 5.4.0

* Adds support for `serverClientId` configuration option.
* Makes `Google-Services.info` file optional.

## 5.3.1

* Suppresses warnings for pre-iOS-13 codepaths.

## 5.3.0

* Supports arm64 iOS simulators by increasing GoogleSignIn dependency to version 6.2.

## 5.2.7

* Fixes library_private_types_in_public_api, sort_child_properties_last and use_key_in_widget_constructors
  lint warnings.

## 5.2.6

* Switches to an internal method channel, rather than the default.

## 5.2.5

* Splits from `google_sign_in` as a federated implementation.
