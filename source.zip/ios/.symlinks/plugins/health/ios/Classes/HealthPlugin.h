#import <Flutter/Flutter.h>

@interface HealthPlugin : NSObject<FlutterPlugin>
@end
