package cachet.plugins.example_app

import android.os.Bundle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
